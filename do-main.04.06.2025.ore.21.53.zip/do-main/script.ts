document.addEventListener('DOMContentLoaded', () => {
    const tocToggles = document.querySelectorAll<HTMLElement>('.toc-toggle');
    
    tocToggles.forEach((toggle: HTMLElement) => {
        toggle.addEventListener('click', (e: MouseEvent) => {
            const button = e.currentTarget as HTMLElement;
            button.classList.toggle('active');
            const content = button.nextElementSibling as HTMLElement;
            if (content.classList.contains('show')) {
                content.classList.remove('show');
                content.style.maxHeight = '0';
            } else {
                content.classList.add('show');
                content.style.maxHeight = `${content.scrollHeight}px`;
            }
        });
    });
}); 