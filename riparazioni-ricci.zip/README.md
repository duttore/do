# Riparazioni Ricci - Sito Web

Sito web per l'attività di riparazione macchine da cucire a Firenze.

## Tecnologie Utilizzate

- Next.js
- TypeScript
- Tailwind CSS
- Font Awesome

## Requisiti

- Node.js (versione 18 o superiore)
- npm (versione 10 o superiore)

## Installazione

1. Clona il repository:
```bash
git clone https://github.com/tuousername/riparazioni-ricci.git
cd riparazioni-ricci
```

2. Installa le dipendenze:
```bash
npm install
```

3. Avvia il server di sviluppo:
```bash
npm run dev
```

4. Apri [http://localhost:3000](http://localhost:3000) nel tuo browser.

## Script Disponibili

- `npm run dev` - Avvia il server di sviluppo
- `npm run build` - Compila il progetto per la produzione
- `npm start` - Avvia il server di produzione
- `npm run lint` - Esegue il linting del codice
- `npm run compile` - Compila i file TypeScript
- `npm run compile:script` - Compila script.ts separatamente

## Struttura del Progetto

```
riparazioni-ricci/
├── components/     # Componenti React
├── pages/         # Pagine Next.js
├── public/        # File statici
├── styles/        # File CSS
└── script.ts      # Script principale
```

## Licenza

© 2024 Stefano Ricci - Tutti i diritti riservati
