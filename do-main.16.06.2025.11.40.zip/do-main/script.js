document.addEventListener('DOMContentLoaded', () => {
    // Gestione menu mobile
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navDesktop = document.querySelector('.nav-desktop');

    mobileMenuBtn?.addEventListener('click', () => {
        navDesktop?.classList.toggle('active');
        mobileMenuBtn.classList.toggle('active');
    });

    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                navDesktop?.classList.remove('active');
                mobileMenuBtn?.classList.remove('active');
            }
        });
    });

    // Gestione modal contatti
    const contattiLink = document.getElementById('contatti-link');
    const contattiModal = document.getElementById('contatti-modal');
    const modalClose = document.querySelector('.modal-close');

    contattiLink?.addEventListener('click', (e) => {
        e.preventDefault();
        contattiModal?.classList.add('show');
        document.body.style.overflow = 'hidden';
    });

    modalClose?.addEventListener('click', () => {
        contattiModal?.classList.remove('show');
        document.body.style.overflow = 'auto';
    });

    contattiModal?.addEventListener('click', (e) => {
        if (e.target === contattiModal) {
            contattiModal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    });

    // Gestione scroll progress
    const scrollProgress = document.createElement('div');
    scrollProgress.className = 'scroll-progress';
    document.body.appendChild(scrollProgress);

    function updateScrollProgress() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrollPercentage = (scrollTop / scrollHeight) * 100;
        scrollProgress.style.width = scrollPercentage + '%';
    }

    window.addEventListener('scroll', updateScrollProgress);

    // Gestione header visibilità
    let lastScrollTop = 0;
    const header = document.querySelector('.header');
    const scrollThreshold = 100;

    function handleHeader() {
        const currentScroll = window.pageYOffset || document.documentElement.scrollTop;

        if (currentScroll <= scrollThreshold) {
            header?.classList.remove('hide');
            header?.classList.add('show');
            return;
        }

        if (currentScroll > lastScrollTop) {
            header?.classList.remove('show');
            header?.classList.add('hide');
        } else {
            header?.classList.remove('hide');
            header?.classList.add('show');
        }

        lastScrollTop = currentScroll;
    }

    window.addEventListener('scroll', handleHeader);

    // Gestione link attivi
    function setActiveNavLink() {
        const sections = document.querySelectorAll('section[id]');
        const scrollPosition = window.scrollY + 100;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === '#' + sectionId) {
                        link.classList.add('active');
                    }
                });
            }
        });

        // Imposta attivo il link della home page
        if (window.location.pathname.endsWith('index.html') || window.location.pathname.endsWith('/')) {
            const scrollPosition = window.scrollY;
            if (scrollPosition < 100) {
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.classList.remove('active');
                });
                const homeLink = document.querySelector('.nav-link[href="#servizi"]');
                if (homeLink) homeLink.classList.add('active');
            }
        }
    }

    window.addEventListener('scroll', setActiveNavLink);
    setActiveNavLink();

    // Gestione animazioni
    function isElementInViewport(el) {
        const rect = el.getBoundingClientRect();
        const windowHeight = window.innerHeight || document.documentElement.clientHeight;

        return (rect.top <= windowHeight * 0.8 && rect.bottom >= windowHeight * 0.2);
    }

    function handleScrollAnimations() {
        const animatedElements = document.querySelectorAll(
            '.fade-in-up, .fade-in-left, .fade-in-right, ' +
            '.service-card, .issue-card, .pricing-card, .problem-card, ' +
            '.social-link.facebook, .section-header'
        );

        animatedElements.forEach(element => {
            if (isElementInViewport(element)) {
                element.classList.add('visible');
            }
        });
    }

    let scrollTimeout;
    handleScrollAnimations();

    window.addEventListener('scroll', () => {
        window.clearTimeout(scrollTimeout);
        scrollTimeout = window.setTimeout(handleScrollAnimations, 66);
    });

    // Gestione accordion
    const accordionHeaders = document.querySelectorAll('.accordion-header');

    accordionHeaders.forEach(header => {
        header.addEventListener('click', (e) => {
            const currentHeader = e.currentTarget;
            const accordionContent = currentHeader.nextElementSibling;
            currentHeader.classList.toggle('active');

            if (currentHeader.classList.contains('active')) {
                accordionContent.style.maxHeight = accordionContent.scrollHeight + 'px';
            } else {
                accordionContent.style.maxHeight = '0';
            }

            // Chiudi gli altri accordion
            document.querySelectorAll('.accordion-header').forEach(otherHeader => {
                if (otherHeader !== currentHeader) {
                    otherHeader.classList.remove('active');
                    otherHeader.nextElementSibling.style.maxHeight = '0';
                }
            });
        });
    });
}); 